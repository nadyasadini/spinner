import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:maps/main.dart'; // Ganti sesuai nama package kamu

void main() {
  testWidgets('App shows map screen with AppBar title', (WidgetTester tester) async {
    // Build app
    await tester.pumpWidget(const MyMapApp());

    // Verifikasi judul AppBar muncul
    expect(find.text('🗺 Peta Interaktif'), findsOneWidget);
    
    // Verifikasi widget GoogleMap muncul
    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.byType(AppBar), findsOneWidget);
  });
}