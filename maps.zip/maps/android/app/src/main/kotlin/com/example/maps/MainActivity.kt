package com.example.maps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
