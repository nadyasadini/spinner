import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Grafik Nilai',
      debugShowCheckedModeBanner: false,
      home: const GrafikPage(),
    );
  }
}

class GrafikPage extends StatelessWidget {
  const GrafikPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Grafik'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: LineChart(
          LineChartData(
            backgroundColor: Colors.white,
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(
                sideTitles: SideTitles(showTitles: true, reservedSize: 35),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (value, meta) {
                    final labels = ['A', 'B', 'C', 'D', 'E', 'F'];
                    if (value.toInt() >= 0 && value.toInt() < labels.length) {
                      return Text(labels[value.toInt()]);
                    }
                    return const Text('');
                  },
                  reservedSize: 30,
                ),
              ),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            borderData: FlBorderData(show: true),
            gridData: FlGridData(show: true),
            minX: 0,
            maxX: 5,
            minY: 0,
            maxY: 100,
            lineBarsData: [
              LineChartBarData(
                spots: [
                  FlSpot(0, 75),
                  FlSpot(1, 80),
                  FlSpot(2, 60),
                  FlSpot(3, 90),
                  FlSpot(4, 70),
                  FlSpot(5, 85),
                ],
                isCurved: true,
                color: Colors.teal,
                barWidth: 4,
                belowBarData: BarAreaData(show: true, color: Colors.teal.withOpacity(0.3)),
                dotData: FlDotData(show: true),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
