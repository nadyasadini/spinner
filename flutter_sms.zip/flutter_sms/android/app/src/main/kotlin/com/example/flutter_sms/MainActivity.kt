package com.example.flutter_sms

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
