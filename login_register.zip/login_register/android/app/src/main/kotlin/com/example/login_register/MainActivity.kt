package com.example.login_register

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
