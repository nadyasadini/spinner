import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = const Color.fromARGB(255, 9, 32, 107); // Biru tua
  static const Color secondary = Color(0xFF1976D2); // Biru sedang
  static const Color accent = Color(0xFF64B5F6); // Biru terang
  static const Color background = Color(0xFFF5F5F5); // Abu terang
  static const Color textPrimary = Color(0xFF212121); // Hitam keabu
  static const Color textSecondary = Color(0xFF757575); // Abu tua
  static const Color error = const Color.fromARGB(255, 9, 32, 107); // Merah
  static const Color success = const Color.fromARGB(255, 9, 32, 107); // Hijau
  static const Color white = Colors.white;
  static const Color black = Colors.black;

  // Tambahan agar tidak error
  static const Color inputBackground = Color(0xFFF0F0F0);
  static const Color inputBorder = Color(0xFFCCCCCC);
  static const Color primaryDark = const Color.fromARGB(255, 9, 32, 107);
}