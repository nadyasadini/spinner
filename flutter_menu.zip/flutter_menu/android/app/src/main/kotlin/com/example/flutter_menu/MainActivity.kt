package com.example.flutter_menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
