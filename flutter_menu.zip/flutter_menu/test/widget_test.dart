import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_menu/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('Menampilkan halaman utama dan menu drawer', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Pastikan teks utama tampil
    expect(find.text('Selamat datang'), findsOneWidget);

    // Ketuk ikon menu drawer (ikon garis tiga)
    await tester.tap(find.byTooltip('Open navigation menu'));
    await tester.pumpAndSettle();

    // Pastikan menu Preferences muncul
    expect(find.text('Preferences'), findsOneWidget);
  });

  testWidgets('Navigasi ke halaman Preferences dan toggle dark mode', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    // Buka drawer
    await tester.tap(find.byTooltip('Open navigation menu'));
    await tester.pumpAndSettle();

    // Navigasi ke Preferences
    await tester.tap(find.text('Preferences'));
    await tester.pumpAndSettle();

    // Pastikan halaman Preferences tampil
    expect(find.text('Dark Mode'), findsOneWidget);

    // Dapatkan nilai awal Switch
    final initialSwitchTile = tester.widget<SwitchListTile>(find.byType(SwitchListTile));
    final initialValue = initialSwitchTile.value;

    // Toggle switch
    await tester.tap(find.byType(SwitchListTile));
    await tester.pumpAndSettle();

    // Cek perubahan nilai
    final newSwitchTile = tester.widget<SwitchListTile>(find.byType(SwitchListTile));
    expect(newSwitchTile.value, isNot(initialValue));
  });
}