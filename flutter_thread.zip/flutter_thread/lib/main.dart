import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Async Thread Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const AsyncExamplePage(),
    );
  }
}

class AsyncExamplePage extends StatefulWidget {
  const AsyncExamplePage({super.key});

  @override
  State<AsyncExamplePage> createState() => _AsyncExamplePageState();
}

class _AsyncExamplePageState extends State<AsyncExamplePage> {
  String _status = "Menunggu...";
  bool _isProcessing = false;

  Future<void> _startLongProcess() async {
    setState(() {
      _status = "Memproses...";
      _isProcessing = true;
    });

    await Future.delayed(const Duration(seconds: 3));

    setState(() {
      _status = "Selesai!";
      _isProcessing = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    Icon statusIcon;
    Color statusColor;

    if (_status == "Memproses...") {
      statusIcon = const Icon(Icons.hourglass_top, color: Colors.orange, size: 40);
      statusColor = Colors.orange.shade100;
    } else if (_status == "Selesai!") {
      statusIcon = const Icon(Icons.check_circle, color: Colors.green, size: 40);
      statusColor = Colors.green.shade100;
    } else {
      statusIcon = const Icon(Icons.info_outline, color: Colors.grey, size: 40);
      statusColor = Colors.grey.shade200;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Thread & Async Flutter')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Column(
                  children: [
                    statusIcon,
                    const SizedBox(height: 8),
                    Text(
                      _status,
                      style: const TextStyle(fontSize: 24),
                    ),
                    if (_isProcessing) ...[
                      const SizedBox(height: 16),
                      const CircularProgressIndicator(),
                    ]
                  ],
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: _isProcessing ? null : _startLongProcess,
                icon: const Icon(Icons.play_arrow),
                label: const Text("Mulai Proses Async"),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
