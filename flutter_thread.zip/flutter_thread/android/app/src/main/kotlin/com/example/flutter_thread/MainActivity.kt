package com.example.flutter_thread

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
